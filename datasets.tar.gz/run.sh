rm -f *.txt
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator7.jar 100 5000 100 90 1000 1 1 128 &
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator7.jar 100 5000 100 90 1000 2 0 128 &
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator7.jar 100 5000 100 90 1000 3 0 128 &
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator7.jar 100 5000 100 90 1000 4 0 4 &
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator7.jar 100 5000 100 90 1000 5 0 4 &
