rm -f *.txt
nohup /home/rafael/jre1.7.0_55/bin/./java -jar simulator9.jar 100 15000 200 90 1000 1 0 128 all &
